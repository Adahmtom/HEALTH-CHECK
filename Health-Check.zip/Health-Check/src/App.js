import React from "react";
import RoutesWrapper from "./routes";
function App() {
 

  return (
    
        <RoutesWrapper />
     
  );
}

export default App;
