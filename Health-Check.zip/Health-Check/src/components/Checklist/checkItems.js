export const checkItems = [
 {"name":"Safety Needles"} ,
 {"name":"Needles"} ,
 {"name":"edles"} ,
  
];

export const TestList = [
  {
    TestName: "Deoxyribonucleic acid (DNA)",
    PatientName: "John Doe",
    Location: "13, john doe street, Wisconsin, USA",
    Date: "12/09/2021",
  },
  {
    TestName: "Deoxyribonucleic acid (DNA)",
    PatientName: "John Doe",
    Location: "13, john doe street, Wisconsin, USA",
    Date: "12/09/2021",
  },
  {
    TestName: "Deoxyribonucleic acid (DNA)",
    PatientName: "John Doe",
    Location: "13, john doe street, Wisconsin, USA",
    Date: "12/09/2021",
  },
  {
    TestName: "Deoxyribonucleic acid (DNA)",
    PatientName: "John Doe",
    Location: "13, john doe street, Wisconsin, USA",
    Date: "12/09/2021",
  },
  {
    TestName: "Deoxyribonucleic acid (DNA)",
    PatientName: "John Doe",
    Location: "13, john doe street, Wisconsin, USA",
    Date: "12/09/2021",
  },
  {
    TestName: "Deoxyribonucleic acid (DNA)",
    PatientName: "John Doe",
    Location: "13, john doe street, Wisconsin, USA",
    Date: "12/09/2021",
  },
];

export const testTypes = [
  "Deoxyribonucleic acid (DNA)",
  "Ribonucleic acid (RNA)",
  "Blood Test",
  "Genotype",
  "Blood Group",
  "Covid 19",
  "Test Type 5",
  "Test Type 6",
  "Test Type 7",
  "Test Type 8",
  "Test Type 9",
  "Test Type 10",
];
