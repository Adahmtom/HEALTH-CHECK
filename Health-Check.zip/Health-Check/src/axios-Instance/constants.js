export const baseURL = "https://remotehealthcheck.azurewebsites.net/api/v1";

